import React from 'react';
import {createRoot} from 'react-dom/client';
import App from './App';
import './design.css';
import './workspace.css';
createRoot(document.getElementById('root')!).render(<App/>);
